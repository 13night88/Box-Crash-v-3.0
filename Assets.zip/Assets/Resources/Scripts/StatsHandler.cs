﻿using UnityEngine;
using System.Collections;

public class StatsHandler : MonoBehaviour {
	//Класс помогающий выводить статистику уровня в интерфейс


	// Use this for initialization
	void Start () {
		//level_clicks = Camera.main.GetComponent<Level> ().click;
	}
	
	// Update is called once per frame
	void Update () {
		//CountClicks ();
	}
}
