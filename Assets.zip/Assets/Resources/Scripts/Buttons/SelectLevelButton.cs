﻿using UnityEngine;
using System.Collections;

public class SelectLevelButton : Button {
	public int LoadingLevelNumber;
	// Use this for initialization
	void Start () {
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	 public void OnClick(){
		//TODO: Действия при клике;
	}
}
