﻿using UnityEngine;
using System.Collections;

public class Level : MonoBehaviour {

	// Use this for initialization
	public int click;
	public int particlesReady;
	GameObject camera;
	private int box_particles;
	private int boxes;
	private bool is_box_was_destroyed;
	Timer timer;
	

	void Start(){
		InitializeBackGround ();
		Debug.Log (string.Format("Level Started: you have {0} clicks",click));
		camera = GameObject.Find ("Main Camera");
		timer = new Timer (2f);
		string mess = Load ();
		Debug.Log (mess);
		Camera.main.GetComponent<GUI> ().ShowLevelNumber ();
	}
	
	// Update is called once per frame
	void Update () {
		//if (GameObject.FindGameObjectsWithTag ("Box").Length + GameObject.FindGameObjectsWithTag ("Bubble").Length <=0)
		LevelFinish ();
	}


	private void InitializeBackGround(){ //setting bg 
		Background bg = new Background ();
		bg.height = 1f;
		bg.width = 1f;
		//bg.Publish("PBackGround");
	}
	
	
	bool is_level_saved;
	void LevelFinish(){
		Debug.Log ("Boxes: " + GameObject.FindObjectsOfType<Box> ().Length);
			boxes = GameObject.FindObjectsOfType<Box> ().Length; //boxes amount on the scene
			box_particles = GameObject.FindGameObjectsWithTag ("Particle").Length; //particles amount on the scene

			Debug.Log (string.Format ("Particles: {0}, Boxes: {1}, Clicks: {2}", particlesReady, boxes, click));
			if (boxes <= 0 && click >= 0) {
			if (!is_level_saved){
				Debug.Log (string.Format ("Win & clicks left {0}", click));
			    is_level_saved = Save(Application.loadedLevel);
				Camera.main.GetComponent<GUI> ().ShowWinMenu ();

			}
			} else if (boxes > 0 && click <= 0 && particlesReady == 0) {
				Debug.Log (string.Format ("Game Over & boxes left {0}", boxes));
				Camera.main.GetComponent<GUI> ().ShowGameOverMenu ();
			
			}


	}

	bool Save(int level_number){
		string opened_levels = "";
		if(PlayerPrefs.HasKey("Levels")) opened_levels = PlayerPrefs.GetString ("Levels");
		opened_levels += (level_number - 2).ToString ();
		PlayerPrefs.SetString ("Levels", opened_levels);
		PlayerPrefs.Save ();
			
		return true;
	}

	string Load(){
		string opened_levels = PlayerPrefs.GetString ("Levels");
		return ("Loaded levels: " + opened_levels);
	}


	
}


