﻿using UnityEngine;
using System.Collections;

public class LevelInit : MonoBehaviour {

	// Use this for initialization
	void Start () {
		Level _level = new Level ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
