﻿using UnityEngine;
using System.Collections;

public class Settings : MyGameObject {
	public float speed = 3f;
	public int woodenBoxHp = 1; 
	public int bubbleBoxHp = 2;
	public int iceBoxHp = 3;
	public int stoneBoxHp = 4;

}
